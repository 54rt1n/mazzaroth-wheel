Mazzaroth constellation data sources

This archive supplies the preferred, editable JSON form of all displayed line datasets, their complete endpoint coordinates, original upstream skyculture files, custom research compilations, source notices, and licenses. No illustrations are included.

Each tradition retains its own license; this is a collection of independent data sets. In particular, the Navajo data is under GNU GPL version 2, with the complete license in research/skycultures/navajo/COPYING. Modified data is also supplied here as editable JSON: the only changes to official source line sequences are mechanical schema and identifier conversion. Custom Hebrew/Iranian comparisons are separately credited and preserve their research limitations.

The combined constellations.json and endpoint-catalogue.json can be edited or consumed directly. The included project builder documents the conversion and validation, and expects the Mazzaroth project's base catalogue files when run inside the full source checkout. The full project catalogue is not needed to read, edit, or use these complete normalized data files.
